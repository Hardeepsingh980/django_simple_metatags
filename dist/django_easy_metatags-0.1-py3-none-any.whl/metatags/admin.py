from django.contrib import admin
from .models import MetaTag

admin.site.register(MetaTag)