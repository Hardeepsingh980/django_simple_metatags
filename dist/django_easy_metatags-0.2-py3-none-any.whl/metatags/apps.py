from django.apps import AppConfig


class MetatagsConfig(AppConfig):
    name = 'metatags'
